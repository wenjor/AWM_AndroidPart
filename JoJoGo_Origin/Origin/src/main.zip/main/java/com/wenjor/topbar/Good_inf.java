package com.wenjor.topbar;


public class Good_inf {
    public String id ;
    public String name;
    public String description;
    public  String  cateId;
    public String  status;
    //public int provider;
    public String price;
    //public String createAt;
   // public String updateAt;

    public Good_inf(){
        //this.id =null;
        this.name=null;
        this.description = null;
        this.cateId=null;
        this.status=null;
        this.price=null;


    }
}
